<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Infomensuales */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="infomensuales-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'no_sesion')->textInput() ?>

    <?= $form->field($model, 'actividades')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'objetivo_alcanzado')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'observacion')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'fecha')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Crear') : Yii::t('app', 'Actualizar'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
