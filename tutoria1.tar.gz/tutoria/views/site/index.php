<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Bienvenido!</h1>

        

        <p><a class="btn btn-lg btn-success" href="http://localhost:8080/usuarios">Iniciar Registros</a></p>
    </div>

    <div class="body-content">

       
                
              
         

        