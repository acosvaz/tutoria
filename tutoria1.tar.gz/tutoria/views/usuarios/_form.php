<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Usuarios */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="usuarios-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nombre')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'paterno')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'materno')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'genero')->textInput() ?>

    <?= $form->field($model, 'tipo_usuario')->textInput() ?>

    <?= $form->field($model, 'matricula')->textInput() ?>

    <?= $form->field($model, 'carrera')->textInput() ?>

    <?= $form->field($model, 'semestre')->textInput() ?>

    <?= $form->field($model, 'grupo')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'nu_diagnostico')->textInput() ?>

    <?= $form->field($model, 'nu_infomensual')->textInput() ?>

    <?= $form->field($model, 'nu_infosemestral')->textInput() ?>

    <?= $form->field($model, 'nu_reporte')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Crear') : Yii::t('app', 'Actualizar'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
