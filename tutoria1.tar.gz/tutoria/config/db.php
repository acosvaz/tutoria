<?php

return [
    'class' => 'yii\db\Connection',
    //'dsn' => 'mysql:host=localhost;dbname=yii2basic',
    'dsn' => 'pgsql:host=localhost;dbname=tutorias',
    'username' => 'ivette',
    'password' => 'bakatotesto',
    //'charset' => 'utf8',
];
