<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "diagnosticos".
 *
 * @property integer $id
 * @property string $descripcion
 * @property string $situacion_irregular
 * @property string $plan_de_accion
 *
 * @property Usuarios[] $usuarios
 * @property Usuarios[] $usuarios0
 */
class Diagnosticos extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'diagnosticos';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['descripcion', 'situacion_irregular', 'plan_de_accion'], 'required'],
            [['descripcion', 'situacion_irregular', 'plan_de_accion'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            //'id' => Yii::t('app', 'ID'),
            'descripcion' => Yii::t('app', 'Descripcion'),
            'situacion_irregular' => Yii::t('app', 'Situacion Irregular'),
            'plan_de_accion' => Yii::t('app', 'Plan De Accion'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios()
    {
        return $this->hasMany(Usuarios::className(), ['nu_diagnostico' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios0()
    {
        return $this->hasMany(Usuarios::className(), ['nu_diagnostico' => 'id']);
    }
}
