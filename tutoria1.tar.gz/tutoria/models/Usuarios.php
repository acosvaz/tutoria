<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "usuarios".
 *
 * @property integer $id
 * @property string $nombre
 * @property string $paterno
 * @property string $materno
 * @property string $genero
 * @property string $tipo_usuario
 * @property string $matricula
 * @property string $carrera
 * @property string $semestre
 * @property string $grupo
 * @property integer $nu_diagnostico
 * @property integer $nu_infomensual
 * @property integer $nu_infosemestral
 * @property integer $nu_reporte
 *
 * @property Diagnosticos $nuDiagnostico
 * @property Diagnosticos $nuDiagnostico0
 * @property Infomensuales $nuInfomensual
 * @property Infomensuales $nuInfomensual0
 * @property Infosemestrales $nuInfosemestral
 * @property Infosemestrales $nuInfosemestral0
 * @property Reportes $nuReporte
 * @property Reportes $nuReporte0
 */
class Usuarios extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'usuarios';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nombre', 'paterno', 'genero', 'tipo_usuario', 'matricula', 'carrera', 'semestre', 'grupo'], 'required'],
            [['nombre', 'paterno', 'materno', 'grupo'], 'string'],
            [['genero', 'tipo_usuario', 'matricula', 'carrera', 'semestre'], 'number'],
            [['nu_diagnostico', 'nu_infomensual', 'nu_infosemestral', 'nu_reporte'], 'integer'],
            [['nu_diagnostico'], 'exist', 'skipOnError' => true, 'targetClass' => Diagnosticos::className(), 'targetAttribute' => ['nu_diagnostico' => 'id']],
            [['nu_diagnostico'], 'exist', 'skipOnError' => true, 'targetClass' => Diagnosticos::className(), 'targetAttribute' => ['nu_diagnostico' => 'id']],
            [['nu_infomensual'], 'exist', 'skipOnError' => true, 'targetClass' => Infomensuales::className(), 'targetAttribute' => ['nu_infomensual' => 'id']],
            [['nu_infomensual'], 'exist', 'skipOnError' => true, 'targetClass' => Infomensuales::className(), 'targetAttribute' => ['nu_infomensual' => 'id']],
            [['nu_infosemestral'], 'exist', 'skipOnError' => true, 'targetClass' => Infosemestrales::className(), 'targetAttribute' => ['nu_infosemestral' => 'id']],
            [['nu_infosemestral'], 'exist', 'skipOnError' => true, 'targetClass' => Infosemestrales::className(), 'targetAttribute' => ['nu_infosemestral' => 'id']],
            [['nu_reporte'], 'exist', 'skipOnError' => true, 'targetClass' => Reportes::className(), 'targetAttribute' => ['nu_reporte' => 'id']],
            [['nu_reporte'], 'exist', 'skipOnError' => true, 'targetClass' => Reportes::className(), 'targetAttribute' => ['nu_reporte' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            //'id' => Yii::t('app', 'ID'),
            'nombre' => Yii::t('app', 'Nombre'),
            'paterno' => Yii::t('app', 'Apellido Paterno'),
            'materno' => Yii::t('app', 'Apellido Materno'),
            'genero' => Yii::t('app', 'Genero'),
            'tipo_usuario' => Yii::t('app', 'Tipo de Usuario'),
            'matricula' => Yii::t('app', 'Matricula'),
            'carrera' => Yii::t('app', 'Carrera'),
            'semestre' => Yii::t('app', 'Semestre'),
            'grupo' => Yii::t('app', 'Grupo'),
            'nu_diagnostico' => Yii::t('app', 'Diagnostico'),
            'nu_infomensual' => Yii::t('app', 'Infomensual'),
            'nu_infosemestral' => Yii::t('app', 'Infosemestral'),
            'nu_reporte' => Yii::t('app', 'Reporte'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuDiagnostico()
    {
        return $this->hasOne(Diagnosticos::className(), ['id' => 'nu_diagnostico']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuDiagnostico0()
    {
        return $this->hasOne(Diagnosticos::className(), ['id' => 'nu_diagnostico']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuInfomensual()
    {
        return $this->hasOne(Infomensuales::className(), ['id' => 'nu_infomensual']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuInfomensual0()
    {
        return $this->hasOne(Infomensuales::className(), ['id' => 'nu_infomensual']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuInfosemestral()
    {
        return $this->hasOne(Infosemestrales::className(), ['id' => 'nu_infosemestral']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuInfosemestral0()
    {
        return $this->hasOne(Infosemestrales::className(), ['id' => 'nu_infosemestral']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuReporte()
    {
        return $this->hasOne(Reportes::className(), ['id' => 'nu_reporte']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNuReporte0()
    {
        return $this->hasOne(Reportes::className(), ['id' => 'nu_reporte']);
    }
}
