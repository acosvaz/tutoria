<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "infosemestrales".
 *
 * @property integer $id
 * @property string $tipo_de_atencion
 * @property string $canalizacion
 * @property string $area
 * @property string $descripcion
 * @property string $fecha
 *
 * @property Usuarios[] $usuarios
 * @property Usuarios[] $usuarios0
 */
class Infosemestrales extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'infosemestrales';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tipo_de_atencion', 'canalizacion', 'area', 'descripcion', 'fecha'], 'required'],
            [['tipo_de_atencion', 'canalizacion', 'area', 'descripcion'], 'string'],
            [['fecha'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'tipo_de_atencion' => Yii::t('app', 'Tipo De Atencion'),
            'canalizacion' => Yii::t('app', 'Canalizacion'),
            'area' => Yii::t('app', 'Area'),
            'descripcion' => Yii::t('app', 'Descripcion'),
            'fecha' => Yii::t('app', 'Fecha'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios()
    {
        return $this->hasMany(Usuarios::className(), ['nu_infosemestral' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios0()
    {
        return $this->hasMany(Usuarios::className(), ['nu_infosemestral' => 'id']);
    }
}
