<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "infomensuales".
 *
 * @property integer $id
 * @property string $no_sesion
 * @property string $actividades
 * @property string $objetivo_alcanzado
 * @property string $observacion
 * @property string $fecha
 *
 * @property Usuarios[] $usuarios
 * @property Usuarios[] $usuarios0
 */
class Infomensuales extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'infomensuales';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['no_sesion', 'actividades', 'objetivo_alcanzado', 'observacion', 'fecha'], 'required'],
            [['no_sesion'], 'number'],
            [['actividades', 'objetivo_alcanzado', 'observacion'], 'string'],
            [['fecha'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            //'id' => Yii::t('app', 'ID'),
            'no_sesion' => Yii::t('app', 'No Sesion'),
            'actividades' => Yii::t('app', 'Actividades'),
            'objetivo_alcanzado' => Yii::t('app', 'Objetivo Alcanzado'),
            'observacion' => Yii::t('app', 'Observacion'),
            'fecha' => Yii::t('app', 'Fecha'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios()
    {
        return $this->hasMany(Usuarios::className(), ['nu_infomensual' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios0()
    {
        return $this->hasMany(Usuarios::className(), ['nu_infomensual' => 'id']);
    }
}
