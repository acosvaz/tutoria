<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "reportes".
 *
 * @property integer $id
 * @property string $fecha
 * @property string $incidencia
 * @property string $tipo_de_incidencia
 * @property string $asignatura
 *
 * @property Usuarios[] $usuarios
 * @property Usuarios[] $usuarios0
 */
class Reportes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'reportes';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['fecha', 'incidencia', 'tipo_de_incidencia', 'asignatura'], 'required'],
            [['fecha'], 'safe'],
            [['incidencia', 'tipo_de_incidencia', 'asignatura'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'fecha' => Yii::t('app', 'Fecha'),
            'incidencia' => Yii::t('app', 'Incidencia'),
            'tipo_de_incidencia' => Yii::t('app', 'Tipo De Incidencia'),
            'asignatura' => Yii::t('app', 'Asignatura'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios()
    {
        return $this->hasMany(Usuarios::className(), ['nu_reporte' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios0()
    {
        return $this->hasMany(Usuarios::className(), ['nu_reporte' => 'id']);
    }
}
